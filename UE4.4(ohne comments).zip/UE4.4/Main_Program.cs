﻿using UE4_4_Book;
using UE4_4_Library; //Dependencies, Main programm greift zu auf Book und Libr.

namespace UE4_4_Main
{
    internal class Main_Program
    {
        static void Main(string[] args) 
        {
            Book b1 = new ("Dune", 13, false);
            Book b2 = new ("uneD", 34 );
            Book b3 = new ("Doon", 94 );
            Book b4 = new ("Nood", 22);

            Book[] collection1 = { b1 , b2 , b3 , b4 };
            Book[] collection2 = { b1 , b3 };


            Library lib1 = new Library(collection1);
            Library lib2 = new Library(collection2);

            Return:

                Console.WriteLine("Current inventory of books:");
                lib1.ShowBooks();

                Console.WriteLine("Select an option and press [Enter] 1 for Borrow, 2 for Return, 3 to exit ");
                try
                {
                    int userSelection = Int32.Parse(Console.ReadLine());
                    while (userSelection != 3)
                    {
                        switch (userSelection)
                        {
                            case 1:
                                Console.WriteLine("You have chosen to borrow a book, enter ISBN");
                                int selectedborrowISBN = Int32.Parse(Console.ReadLine());
                                lib1.BorrowBook(selectedborrowISBN);
                                break;
                            case 2:
                                Console.WriteLine("You have chosen to return a book, enter ISBN");
                                int selectedreturnISBN = Int32.Parse(Console.ReadLine());
                                lib1.ReturnBook(selectedreturnISBN);
                                break;
                            case 3:
                                Environment.Exit(0);
                                break;
                            default:
                                Console.WriteLine("Invalid input");
                                break;

                        }
                        goto Return;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Invalid input");
                    goto Return;
                }
        }
    }
}
